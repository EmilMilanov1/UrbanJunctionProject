﻿using Microsoft.AspNetCore.Mvc;

namespace UrbanJunction.Web.Controllers
{
    public class CreditsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
